﻿CREATE TABLE ComponentesProyecto (
    CodigoProyecto NVARCHAR(255) NOT NULL,
    IdEmpleado NVARCHAR(255) NOT NULL,
    Puesto NVARCHAR(255) NOT NULL,
    PorcentajeDedicacion FLOAT NOT NULL,
	Extras REAl NOT NULL
);
